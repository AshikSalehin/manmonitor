angular.module('manmon', ["ngRoute", "ngMaterial"]);
