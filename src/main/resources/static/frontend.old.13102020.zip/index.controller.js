(function () {
    //Your_Name
    'use strict'
    angular.module('manmon')
        .controller("homeController", homeController);
    /**@ngInject */
    function homeController($scope, $interval, $http) {
        debugger
        var vm = this;
        vm.demoMode = 1;
        vm.timeToGraph = "00:00";
        vm.toViewController = false;
        $scope.temperature = 0;
        $scope.humidity = 0;
        $scope.ligntIntensity = 0;
        $scope.noiseLevel = 0;
        $scope.light = true;
        $scope.humidifier = true;
        var currentHumidityArray = [];
        vm.initiaSynchronization = true;

        init();

        function init() {
            temperatureGraph();
            humidityGraph();
            lightGraph();
        }
        
        //        socket code
        var stompClient = null;
        var socket = null;
        function Sockconnect() {
            socket = new SockJS('/gs-guide-websocket');
            stompClient = Stomp.over(socket);
            stompClient.connect({}, function (frame) {
                
                console.log('Connected: ' + frame);
                stompClient.subscribe('/topic/sensorinfo', function (envStatus) {
                var environmentStatus = JSON.parse(envStatus.body);
                console.log(environmentStatus);
                if(vm.initiaSynchronization){
                    if(environmentStatus.relayInfo.replay01 == "1"){
                        $scope.light = true;
                    }
                    else{
                        $scope.light = false;
                    }
                    if(environmentStatus.relayInfo.replay02 == "1"){
                        $scope.humidifier = true;
                    }
                    else{
                        $scope.humidifier = false;
                    }
                    vm.initiaSynchronization = false;
                }
                if(environmentStatus.relayInfo.replay01 == "1"){
                    vm.lampSwitchStatus = true;
                }
                else{
                    vm.lampSwitchStatus = false;
                }
                if(environmentStatus.relayInfo.replay02 == "1"){
                    vm.dehumidifierSwitchStatus = true;
                }
                else{
                    vm.dehumidifierSwitchStatus = false;
                }
                $scope.temperature = parseFloat(environmentStatus.sensorInfo.temperature).toFixed(2);
                $scope.humidity = parseFloat(environmentStatus.sensorInfo.humidity).toFixed(2);
                $scope.ligntIntensity = parseFloat(environmentStatus.sensorInfo.light).toFixed(2);
                var getTime = environmentStatus.time;
                vm.timeToGraph = getTime.charAt(10) + getTime.charAt(11) + ":" + getTime.charAt(12) + getTime.charAt(13);
                
//                getTime.charAt(8) + getTime.charAt(9) + ":" +
                var sensorProcessedData = {};
                sensorProcessedData.temperature = angular.copy($scope.temperature);
                sensorProcessedData.humidity = angular.copy($scope.humidity);
                sensorProcessedData.light = angular.copy($scope.ligntIntensity);
                temperatureGraph(sensorProcessedData, tempArray);
                humidityGraph(sensorProcessedData, humArray);
                lightGraph(sensorProcessedData, lightArray);
                
                });
                
            });
            vm.toViewController = true;
        }

        var tempArray = [
            ['Time', 'Temperature'],
            ['20:04', 15],
            ['20:05', 9],
            ['20:06', 21.5],
            ['20:07', 12.3],
            ['20:08', 18],
            ['20:09', 11],
            ['20:10', 10],
            ['20:11', 16],
            ['20:12', 11],
            ['20:13', 18.7],
            ['20:14', 20],
            ['20:15', 11],
            ['20:16', 10.5],
            ['20:04', 10],
            ['20:05', 21],
            ['20:06', 11.5],
            ['20:07', 17],
            ['20:08', 12],
            ['20:09', 9],
            ['20:10', 13],
            ['20:11', 17],
            ['20:12', 16],
            ['20:13', 11.7],
            ['20:14', 12],
            ['20:15', 11],
            ['20:16', 10.5],
            ['20:13', 11.7],
            ['20:14', 12],
            ['20:15', 11],
            ['20:16', 10.5]
        ]
        var humArray = [
            ['Time', 'Humidity'],
            ['20:04', 10],
            ['20:05', 11],
            ['20:06', 11.5],
            ['20:07', 12.3],
            ['20:08', 12],
            ['20:09', 9],
            ['20:10', 13],
            ['20:11', 17],
            ['20:12', 16],
            ['20:13', 11.7],
            ['20:14', 12],
            ['20:15', 11],
            ['20:16', 10.5],
            ['20:04', 10],
            ['20:05', 11],
            ['20:06', 11.5],
            ['20:07', 12.3],
            ['20:08', 12],
            ['20:09', 9],
            ['20:10', 13],
            ['20:11', 17],
            ['20:12', 16],
            ['20:13', 11.7],
            ['20:14', 12],
            ['20:15', 11],
            ['20:16', 10.5],
            ['20:13', 11.7],
            ['20:14', 12],
            ['20:15', 11],
            ['20:16', 10.5]
        ]
        var lightArray = [
            ['Time', 'Light Intensity'],
            ['20:04', 5],
            ['20:05', 11],
            ['20:06', 20],
            ['20:07', 12.3],
            ['20:08', 7],
            ['20:09', 9],
            ['20:10', 13],
            ['20:11', 17],
            ['20:12', 16],
            ['20:13', 15],
            ['20:14', 12],
            ['20:15', 11],
            ['20:16', 10.5],
            ['20:04', 16],
            ['20:05', 11],
            ['20:06', 11.5],
            ['20:07', 6],
            ['20:08', 12],
            ['20:09', 9],
            ['20:10', 10],
            ['20:11', 17],
            ['20:12', 16],
            ['20:13', 11.7],
            ['20:14', 19],
            ['20:15', 11],
            ['20:16', 10.5],
            ['20:13', 11.7],
            ['20:14', 12],
            ['20:15', 11],
            ['20:16', 10.5]
        ]



//        var ws = new WebSocket("ws://127.0.0.1:5678/");
//        ws.onmessage = function (event) {
//            var content = document.createTextNode(event.data);
//            currentHumidityArray.push(content.data);
//            $scope.humidityInfo = currentHumidityArray.join();
//            //$route.reload();
//            //console.log($scope.humidityInfo);
//            var mock = mokValueUpdate();
//            var getTime = mock.time;
//            //vm.timeToGraph = getTime.charAt(8) + getTime.charAt(9) + ":" + getTime.charAt(10) + getTime.charAt(11);
//            $scope.temperature = mock.temperature.toFixed(2);
//            $scope.humidity = mock.humidity.toFixed(2);
//            $scope.ligntIntensity = mock.light.toFixed(2);
//            temperatureGraph(mock, tempArray);
//            humidityGraph(mock, humArray);
//            lightGraph(mock, lightArray);
//
//            // if (mock.relayInfo.replay01 == "0") {
//            //     $scope.light = false;
//            // }
//            // if (mock.relayInfo.replay01 == "1") {
//            //     $scope.light = true;
//            // }
//            // if (mock.relayInfo.replay02 == "0") {
//            //     $scope.humidifier = false;
//            // }
//            // if (mock.relayInfo.replay02 == "1") {
//            //     $scope.humidifier = true;
//            // }
//
//
//
//            if (vm.toViewController == false) {
//                vm.toViewController = true;
//            }
//            //  sleep(10000);
//        };

        function temperatureGraph(newValue, allTemp) {
            google.charts.load('current', { 'packages': ['corechart'] });
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                var oldArray = allTemp;
                if (newValue) {
                    var updatedArray = changeArrayQueue(oldArray, newValue.temperature);
                    oldArray = updatedArray
                    tempArray = oldArray;
                }
                var data = google.visualization.arrayToDataTable(oldArray);
                var options = {
                    vAxis: {
                        maxValue: 50,
                        minValue: 5
                    },
                    title: 'Temperature Review',
                    curveType: 'function',
                    legend: { position: 'bottom' }
                };

                var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
                chart.draw(data, options);
            }

        }

        function humidityGraph(newValue, allHum) {
            google.charts.load('current', { 'packages': ['corechart'] });
            google.charts.setOnLoadCallback(drawChart);
            var oldArray = allHum;
            if (newValue) {
                var updatedArray = changeArrayQueue(oldArray, newValue.humidity);
                oldArray = updatedArray
                humArray = oldArray;
            }
            function drawChart() {
                var data = google.visualization.arrayToDataTable(oldArray);


                var options = {
                    vAxis: {
                        maxValue: 100,
                        minValue: 5
                    },
                    title: 'Humidity Review',
                    curveType: 'function',
                    legend: { position: 'bottom' }
                };

                var chart2 = new google.visualization.LineChart(document.getElementById('curve_chart2'));
                chart2.draw(data, options);
            }

        }
        function lightGraph(newValue, allLight) {
            google.charts.load('current', { 'packages': ['corechart'] });
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                var oldArray = allLight;
                if (newValue) {
                    var updatedArray = changeArrayQueue(oldArray, newValue.light);
                    oldArray = updatedArray;
                    lightArray = oldArray;
                }
                var data = google.visualization.arrayToDataTable(oldArray);


                var options = {
                    vAxis: {
                        maxValue: 1000,
                        minValue: 5
                    },
                    title: 'Light Intensity Review',
                    curveType: 'function',
                    legend: { position: 'bottom' }
                };

                var chart3 = new google.visualization.LineChart(document.getElementById('curve_chart3'));
                chart3.draw(data, options);
            }

        }

        


        function changeArrayQueue(itemArray, newItem) {
            var i = 0;
            var changedArray = [];
            itemArray.forEach(function (item) {
                if (i != 1) {
                    changedArray.push(item);
                }
                i = i + 1;
            });
             var newItemAsFloat = parseFloat(newItem);
            changedArray.push([vm.timeToGraph, newItemAsFloat]);
            return changedArray;
        }

        function mokValueUpdate() {
            var sensorValue = {};
            sensorValue.temperature = Math.random() * 25;
            sensorValue.humidity = Math.random() * 22;
            sensorValue.light = Math.random() * 29;
            return sensorValue;
        }
        function sleep(milliseconds) {
            const date = Date.now();
            let currentDate = null;
            do {
                currentDate = Date.now();
            } while (currentDate - date < milliseconds);
        }

        vm.activated = true;
        vm.determinateValue = 30;

        // Iterate every 100ms, non-stop and increment
        // the Determinate loader.
        $interval(function () {

            vm.determinateValue += 1;
            if (vm.determinateValue > 100) {
                vm.determinateValue = 30;
            }

        }, 100);
        
        
        Sockconnect();
        
        function httpGet(theUrl)
        {
            var xmlHttp = new XMLHttpRequest();
            xmlHttp.open( "GET", theUrl, false ); // false for synchronous request
            xmlHttp.send( null );
            return xmlHttp.responseText;
        }

        vm.lampProgress = false;

        vm.lampOnOff = lampOnOff;
        function lampOnOff() {
            vm.lampProgress = true;
            var feedback;
            if ($scope.light == true) {
                
                feedback = httpGet("http://192.168.2.114:8080/setlampdown");
                //console.log(feedback);
                if(feedback == "Relay for Lamp is set to Off"){
                    vm.lampProgress = false;
                    $scope.light = false;
                }
             
            }
            else {
                
                feedback = httpGet("http://192.168.2.114:8080/setlampup");
                //console.log(feedback);
                if(feedback == "Relay for Lamp is set to On"){
                    vm.lampProgress = false;
                    $scope.light = true;
                }
         
            }

        }

        
        vm.dehumidifierProgress = false;

        vm.dehumidifierOnOff = dehumidifierOnOff;
        function dehumidifierOnOff() {
            vm.dehumidifierProgress = true;
            var feedback;
            if ($scope.humidifier == true) {
                
                feedback = httpGet("http://192.168.2.114:8080/setdehumidifierdown");
                //console.log(feedback);
                if(feedback == "Relay for Dehumidifier is set to Off"){
                    vm.dehumidifierProgress = false;
                    $scope.humidifier = false;
                }
             
            }
            else {
                
                feedback = httpGet("http://192.168.2.114:8080/setdehumidifierup");
                //console.log(feedback);
                if(feedback == "Relay for Dehumidifier is set to On"){
                    vm.dehumidifierProgress = false;
                    $scope.humidifier = true;
                }
         
            }
        }
        
        
    }
})();